<?php
include "setup.php";
include "kopf.php";

echo "<h1>Willkommen im Verwaltungsbereich</h1>";

include "fuss.php";




 



 