<?php
include "funktionen.php";

include "kopf.php";

echo "<h1>Speisenübersicht</h1>";








include "../fuss.php";