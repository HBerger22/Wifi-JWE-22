<?php
namespace WIFI\Fdb\Model\Row;

class Marke extends RowAbstract{
    protected string $tabelle = "marken";

}