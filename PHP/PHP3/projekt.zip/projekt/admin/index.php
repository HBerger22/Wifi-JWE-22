<?php
include "setup.php";
ist_eingeloggt();

include "kopf.php";


?>

<h1>Administration Fahrzeug-DB</h1>

<p>
    Willkommen in der Fahrzeug-DB. <br>
    Bitte wählen sie einen Menupunkt
</p>
<form action="#" method="post">


</form>

<?php
include "fuss.php";
?>
